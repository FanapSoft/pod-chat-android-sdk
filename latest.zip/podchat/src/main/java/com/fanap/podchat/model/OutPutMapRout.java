package com.fanap.podchat.model;

import com.fanap.podchat.mainmodel.MapRout;

public class OutPutMapRout extends BaseOutPut{

    private MapRout result;

    public MapRout getResult() {
        return result;
    }

    public void setResult(MapRout result) {
        this.result = result;
    }
}
