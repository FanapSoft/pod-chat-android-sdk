package com.fanap.podchat.call.persist;

import android.arch.persistence.room.Entity;

import com.fanap.podchat.call.model.CallHistoryVO;

@Entity
public class CacheCallHistory extends CallHistoryVO {

}