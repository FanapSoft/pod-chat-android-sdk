package com.fanap.podchat.model;

public class OutPutAddContact extends BaseOutPut {

    private ResultAddContact result;

    public ResultAddContact getResult() {
        return result;
    }

    public void setResult(ResultAddContact result) {
        this.result = result;
    }
}
