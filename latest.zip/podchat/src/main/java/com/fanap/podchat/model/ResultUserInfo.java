package com.fanap.podchat.model;

import com.fanap.podchat.mainmodel.UserInfo;

public class ResultUserInfo {
    private UserInfo user;

    public UserInfo getUser() {
        return user;
    }

    public void setUser(UserInfo user) {
        this.user = user;
    }
}
