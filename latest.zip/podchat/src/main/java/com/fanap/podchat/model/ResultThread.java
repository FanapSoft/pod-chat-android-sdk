package com.fanap.podchat.model;

import com.fanap.podchat.mainmodel.Thread;

public class ResultThread {
    private Thread thread;

    public Thread getThread() {
        return thread;
    }

    public void setThread(Thread thread) {
        this.thread = thread;
    }
}
