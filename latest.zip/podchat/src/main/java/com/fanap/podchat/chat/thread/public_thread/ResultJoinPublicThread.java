package com.fanap.podchat.chat.thread.public_thread;

import com.fanap.podchat.mainmodel.Thread;

public class ResultJoinPublicThread {

    private Thread thread;

    public Thread getThread() {
        return thread;
    }

    public void setThread(Thread thread) {
        this.thread = thread;
    }
}
