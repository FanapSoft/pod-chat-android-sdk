package com.fanap.podchat.model;

import com.fanap.podchat.mainmodel.Contact;

public class ResultContacts  extends Contact{

}

