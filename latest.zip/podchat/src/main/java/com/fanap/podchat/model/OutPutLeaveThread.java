package com.fanap.podchat.model;

public class OutPutLeaveThread extends BaseOutPut {

    private ResultLeaveThread result;

    public ResultLeaveThread getResult() {
        return result;
    }

    public void setResult(ResultLeaveThread result) {
        this.result = result;
    }
}
