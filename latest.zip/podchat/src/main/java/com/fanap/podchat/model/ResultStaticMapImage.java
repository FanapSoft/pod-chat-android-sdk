package com.fanap.podchat.model;

import android.graphics.Bitmap;

public class ResultStaticMapImage {
    private Bitmap bitmap;

    public Bitmap getBitmap() {
        return bitmap;
    }

    public void setBitmap(Bitmap bitmap) {
        this.bitmap = bitmap;
    }
}
