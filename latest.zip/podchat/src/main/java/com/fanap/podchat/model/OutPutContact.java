package com.fanap.podchat.model;

public class OutPutContact extends BaseOutPut {

    private ResultContact result;

    public ResultContact getResult() {
        return result;
    }

    public void setResult(ResultContact result) {
        this.result = result;
    }

}
