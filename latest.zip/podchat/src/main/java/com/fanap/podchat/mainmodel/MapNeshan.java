package com.fanap.podchat.mainmodel;

import java.util.List;

public class MapNeshan {
    private long count;
    private List<MapItem> items;

    public long getCount() {
        return count;
    }

    public void setCount(long count) {
        this.count = count;
    }

    public List<MapItem> getItems() {
        return items;
    }

    public void setItems(List<MapItem> items) {
        this.items = items;
    }
}
