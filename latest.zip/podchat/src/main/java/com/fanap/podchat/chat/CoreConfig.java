package com.fanap.podchat.chat;

public class CoreConfig {

    public static String token;

    public static String tokenIssuer = "1";

    public static String typeCode = "default";

    public static Long userId = 0L;

}
