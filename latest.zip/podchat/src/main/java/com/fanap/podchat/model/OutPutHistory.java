package com.fanap.podchat.model;


public class OutPutHistory extends BaseOutPut{

    private ResultHistory result;

    public ResultHistory getResult() {
        return result;
    }

    public void setResult(ResultHistory result) {
        this.result = result;
    }
}
