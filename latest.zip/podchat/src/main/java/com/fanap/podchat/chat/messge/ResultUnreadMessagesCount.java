package com.fanap.podchat.chat.messge;

public class ResultUnreadMessagesCount {

    long unreadsCount;


    public long getUnreadsCount() {
        return unreadsCount;
    }

    public void setUnreadsCount(long unreadsCount) {
        this.unreadsCount = unreadsCount;
    }
}
