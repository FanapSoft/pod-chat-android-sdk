package com.fanap.podchat.call.audio_call;

public interface ICallServiceState {

    public void onEndCallRequested();

}
