package com.fanap.podchat.model;

import com.fanap.podchat.mainmodel.Thread;

public class ResultAddParticipant {
    private Thread thread;


    public Thread getThread() {
        return thread;
    }

    public void setThread(Thread thread) {
        this.thread = thread;
    }
}
