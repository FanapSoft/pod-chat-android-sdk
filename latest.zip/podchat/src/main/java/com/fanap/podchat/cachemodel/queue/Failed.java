package com.fanap.podchat.cachemodel.queue;


public class Failed extends Sending {

}

