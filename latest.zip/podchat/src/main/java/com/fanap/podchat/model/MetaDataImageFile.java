package com.fanap.podchat.model;

public class MetaDataImageFile {
    private FileImageMetaData file;

    public FileImageMetaData getFile() {
        return file;
    }

    public void setFile(FileImageMetaData file) {
        this.file = file;
    }
}
