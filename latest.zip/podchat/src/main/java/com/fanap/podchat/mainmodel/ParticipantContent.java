package com.fanap.podchat.mainmodel;

public class ParticipantContent {
    private long id;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }
}
