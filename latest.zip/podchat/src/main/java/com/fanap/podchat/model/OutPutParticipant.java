package com.fanap.podchat.model;

public class OutPutParticipant extends BaseOutPut {

    private ResultParticipant result;

    public ResultParticipant getResult() {
        return result;
    }

    public void setResult(ResultParticipant result) {
        this.result = result;
    }


}
