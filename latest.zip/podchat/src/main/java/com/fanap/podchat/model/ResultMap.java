package com.fanap.podchat.model;

import com.fanap.podchat.mainmodel.MapItem;

import java.util.List;

public class ResultMap {
    private List<MapItem> maps;

    public List<MapItem> getMaps() {
        return maps;
    }

    public void setMaps(List<MapItem> maps) {
        this.maps = maps;
    }
}
