package com.fanap.podchat.cachemodel.queue;

import android.arch.persistence.room.Entity;

@Entity
public class WaitQueueCache extends SendingQueueCache {

}

