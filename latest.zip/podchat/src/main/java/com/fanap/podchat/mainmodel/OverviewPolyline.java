package com.fanap.podchat.mainmodel;

public class OverviewPolyline {
    private String points;

    public String getPoints() {
        return points;
    }

    public void setPoints(String points) {
        this.points = points;
    }
}
