package com.fanap.podchat.chat.thread.public_thread;

public class ResultIsNameAvailable {

    private String uniqueName;


    public String getUniqueName() {
        return uniqueName;
    }

    public void setUniqueName(String uniqueName) {
        this.uniqueName = uniqueName;
    }
}
