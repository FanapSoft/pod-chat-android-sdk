package com.fanap.podchat.cachemodel.queue;

import android.arch.persistence.room.Entity;

@Entity
public class UploadingQueueCache extends SendingQueueCache {

}
