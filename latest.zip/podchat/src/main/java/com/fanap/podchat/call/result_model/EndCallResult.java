package com.fanap.podchat.call.result_model;

import com.fanap.podchat.call.request_model.EndCallRequest;

public class EndCallResult extends EndCallRequest{

    public EndCallResult() {
        super();
    }


}
