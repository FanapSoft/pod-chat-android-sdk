package com.fanap.podchat.util;

public class LogHelper {
    private static LogHelper logHelper;
    private static boolean log;
}
