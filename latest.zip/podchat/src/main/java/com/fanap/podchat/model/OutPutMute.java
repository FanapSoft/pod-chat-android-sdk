package com.fanap.podchat.model;

public class OutPutMute extends BaseOutPut {

    private String result;

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }
}
