package com.fanap.podchat.model;

public class DeleteMessageContent {

    private long id;



    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }
}