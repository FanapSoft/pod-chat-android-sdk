package com.fanap.podchat.call;

public class CallStatus {

//    REQUESTED(1),
//    CANCELED(2),
//    MISS(3),
//    DECLINED(4),
//    ACCEPTED(5),
//    STARTED(6),
//    ENDED(7),
//    LEAVE(8);




}
