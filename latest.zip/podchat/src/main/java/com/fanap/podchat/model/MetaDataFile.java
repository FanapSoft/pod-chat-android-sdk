package com.fanap.podchat.model;

public class MetaDataFile {
    private FileMetaDataContent file;

    public FileMetaDataContent getFile() {
        return file;
    }

    public void setFile(FileMetaDataContent file) {
        this.file = file;
    }
}
