package com.fanap.podchat.model;

import java.util.List;

public class ResultSetAdmin {

    private List<Admin> admins;

    public List<Admin> getAdmins() {
        return admins;
    }

    public void setAdmins(List<Admin> admins) {
        this.admins = admins;
    }
}
