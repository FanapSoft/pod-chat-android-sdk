package com.fanap.podchat.chat.user.user_roles.model;

import java.util.ArrayList;

public class ResultCurrentUserRoles {

    private ArrayList<String> roles;


    public ArrayList<String> getRoles() {
        return roles;
    }

    public void setRoles(ArrayList<String> roles) {
        this.roles = roles;
    }
}
