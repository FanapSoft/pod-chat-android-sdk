package com.fanap.podchat.model;

public class OutPutAddParticipant extends BaseOutPut {

    private ResultAddParticipant result;

    public ResultAddParticipant getResult() {
        return result;
    }

    public void setResult(ResultAddParticipant result) {
        this.result = result;
    }
}
