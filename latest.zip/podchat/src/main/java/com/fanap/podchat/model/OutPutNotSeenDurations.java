package com.fanap.podchat.model;

public class OutPutNotSeenDurations extends BaseOutPut {

    private ResultNotSeenDuration resultNotSeenDuration;


    public ResultNotSeenDuration getResultNotSeenDuration() {
        return resultNotSeenDuration;
    }

    public void setResultNotSeenDuration(ResultNotSeenDuration resultNotSeenDuration) {
        this.resultNotSeenDuration = resultNotSeenDuration;
    }





}
