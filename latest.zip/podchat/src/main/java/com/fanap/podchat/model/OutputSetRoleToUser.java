package com.fanap.podchat.model;

import android.support.annotation.Nullable;

public class OutputSetRoleToUser {

    ResultSetAdmin resultSetAdmin;

    public ResultSetAdmin getResultSetAdmin() {
        return resultSetAdmin;
    }

    public void setResultSetAdmin(ResultSetAdmin resultSetAdmin) {
        this.resultSetAdmin = resultSetAdmin;
    }
}
