package com.fanap.podchat.model;

import com.fanap.podchat.mainmodel.MapRout;

public class ResultRoutMap {
    private MapRout routs;
}
