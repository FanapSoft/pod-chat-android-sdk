package com.example.chat.application.chatexample;


public class ConstantSample {


    public static final String[] func = {
            "Choose function",
            "get thread",
            "rename thread",
            "get user info",
            "reply message",
            "forward message",
            "send text message",
            "get thread participant",
            "create thread",
            "get thread history",
            "mute thread",
            "un mute thread"
            , "get contacts"
            , "edit message"
            , "add contact"
            , "remove contact"
            , "update contact"
            , "get not seen duration"
            , "pin thread"
            , "unpin thread",
            "Pin Message",
            "Unpin Message",
            "Get Mention List",
            "Is Name Available",
            "Create Public Thread or Channel",
            "Join Public Thread"
    };

    public static final String[] funcSecond = {
            "Choose function"
            , "Sync Contact"
            , "Send file message"
            , "Upload Image"
            , "Upload File"
            , "Remove ConversationVO Participant"
            , "Add ConversationVO Participant"
            , "Leave ConversationVO"
            , "Delete Message"
            , "Search Contact"
            , "Search History"
            , "Send Reply file Message"
            , "Cancel upload"
            , "Retry upload"
            , "Clear History"
            , "Get Admin List",
            "Spam ConversationVO",
            "Seen Message",
            "Update Profile"
    };

    public static final String[] funcThird = {
            "Choose Map function"
            , "Search Map"
            , "Map Routing"
            , "Block"
            , "UnBlock"
            , "GetBlockList"
            , "Update the thread info"
            , "Seen Message List"
            , "delivered Message List"
            , "Create thread with new Message"
            , "Get thread with coreUserId"
            , "map static image"
            , "map reverse"
            , "Send MapLocation Message"
            , "Add Admin"
            , "Start Typing"
            , "Stop Typing"
            , "Remove Admin Rules"
            , "Add Auditor"
            , "Remove Auditor"
            , "CreateThreadWithFile"
            , "Get User Roles",
            "Download Image",
            "Cancel Download Image",
            "Get Cache Size",
            "Clear Cache",
            "Get Storage Size",
            "Clear Storage"

    };
}
