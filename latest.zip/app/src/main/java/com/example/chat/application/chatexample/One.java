package com.example.chat.application.chatexample;

import java.util.ArrayList;

public class One<T> {
    private ArrayList<T> list;

    public ArrayList<T> getList() {
        return list;
    }

    public void setList(ArrayList<T> list) {
        this.list = list;
    }
}
