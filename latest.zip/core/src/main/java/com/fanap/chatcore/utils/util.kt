package com.fanap.chatcore.utils

import java.util.*


fun generateUniqueId(): String {
    return UUID.randomUUID().toString()
}