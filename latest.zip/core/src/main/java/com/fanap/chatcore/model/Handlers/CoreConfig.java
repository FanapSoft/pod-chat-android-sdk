package com.fanap.chatcore.model.Handlers;

public class CoreConfig {

    public static String token;

    public static String tokenIssuer = "1";

    public static String typeCode = "default";

}
