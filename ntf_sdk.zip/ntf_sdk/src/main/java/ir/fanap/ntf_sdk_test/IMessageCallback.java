package ir.fanap.ntf_sdk_test;

@FunctionalInterface
public interface IMessageCallback {

    void onPushMessageReceived(String message);

}
