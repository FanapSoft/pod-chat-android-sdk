package ir.fanap.ntf_sdk_test;


import android.support.annotation.Nullable;

import java.util.List;

@FunctionalInterface
public interface OnWorkDone<T> {

    abstract void onWorkDone(@Nullable T t);
}

