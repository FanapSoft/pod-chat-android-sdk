package ir.fanap.ntf_sdk_test.presenter;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

import ir.fanap.ntf_sdk_test.api.ApiService;
import ir.fanap.ntf_sdk_test.api.ApiUtil;
import ir.fanap.ntf_sdk_test.api.Content;
import ir.fanap.ntf_sdk_test.api.Model;
import ir.fanap.ntf_sdk_test.api.ResponseModel;
import rx.Subscriber;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

public class ApiPresenterImpl implements ApiContract.ApiPresenter {
    private ApiContract.ApiView view;
    private Subscription subscription;
    private ApiService apiService;

    public ApiPresenterImpl(ApiContract.ApiView view) {
        this.view = view;
        this.apiService = ApiUtil.getApiService();
    }

    @Override
    public void setMapOnServer(String token, String userId, String appId) {
        try {

            Model data = new Model();
            data.setUserId(userId);
            data.setProviderAppId(appId);

            Content params = new Content();
            params.setContent(data);

            subscription = apiService.mapOnServer(token, params)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(new ApiPresenter());
        } catch (Exception ex) {
            view.onError(ex.getMessage());
        }
    }

    @Override
    public void cancelRequest() {
        if (subscription != null) {
            subscription.unsubscribe();
        }
    }

    private class ApiPresenter extends Subscriber<JsonObject> {

        @Override
        public void onCompleted() {

        }

        @Override
        public void onError(Throwable e) {
            view.onError(e.getMessage());
        }

        @Override
        public void onNext(JsonObject response) {
            try {
                ResponseModel responseModel = new Gson().fromJson(response,ResponseModel.class);

                view.onResponse(responseModel);
            } catch (Exception ex) {
                ex.printStackTrace();
                view.onError(ex.getMessage());
            }
        }
    }
}
