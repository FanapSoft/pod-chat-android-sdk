package ir.fanap.ntf_sdk_test.api;

import com.google.gson.JsonObject;

import retrofit2.http.Body;
import retrofit2.http.Header;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import rx.Observable;

/**
 * Created by Sadegh-Pc on 3/7/2018.
 */

public interface ApiService {
    @Headers({"Content-Type: application/json"})
    @POST("/v2/push/register/device")
    Observable<JsonObject> mapOnServer(@Header("apiToken") String token,
                                       @Body Content params);

}
