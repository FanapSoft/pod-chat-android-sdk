package ir.fanap.ntf_sdk_test.presenter;

import ir.fanap.ntf_sdk_test.api.ResponseModel;

public interface ApiContract {
    interface ApiView {
        void onResponse(ResponseModel responseModel);

        void onError(String message);
    }

    interface ApiPresenter {
        void setMapOnServer(String token, String userId, String appId);

        void cancelRequest();
    }
}
