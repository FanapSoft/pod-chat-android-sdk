package ir.fanap.ntf_sdk_test.api;

/**
 * Created by Sadegh-Pc on 3/7/2018.
 */

public class ApiUtil {

    static {
        System.loadLibrary("native-lib");
    }

    public static ApiService getApiService() {
        return RetrofitClient.getClient(getAccount()).create(ApiService.class);
    }

    private static native String getAccount();
}
