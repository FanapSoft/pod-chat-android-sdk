package ir.fanap.ntf_sdk_test;

import android.content.Context;
import android.content.IntentFilter;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;


import com.arissystem.touca.tmtp.TmtpPushReceiver;
import com.arissystem.touca.tmtp.TmtpServiceInitialization;
import com.arissystem.touca.tmtp.sdk.receivers.TmtpBootReceiver;

import ir.fanap.ntf_sdk_test.api.ResponseModel;
import ir.fanap.ntf_sdk_test.presenter.ApiContract;
import ir.fanap.ntf_sdk_test.presenter.ApiPresenterImpl;

public class NTFPush implements ApiContract.ApiView {
    private static final String TAG = "PUSH_CLASS";
    private AppCompatActivity activity;
    private Context context;
    private String appId;
    private String apiToken;
    private String userId;
    private ResponseListener responseListener;
    private IMessageCallback iMessageCallbackCallback;


    private NTFPush(PushBuilder nfpPushBuilder) {
        this.activity = nfpPushBuilder.activity;
        this.context = nfpPushBuilder.context;
        this.appId = nfpPushBuilder.appId;
        this.apiToken = nfpPushBuilder.apiToken;
        this.responseListener = nfpPushBuilder.responseListener;
        registerNotificationReceiver();
        subscribeTMTP();
    }


    private AppCompatActivity getActivity() {
        return activity;
    }

    private Context getContext() {
        return context;
    }

    private String getAppId() {
        return appId;
    }

    private String getApiToken() {
        return apiToken;
    }

    public String getUserId() {
        return userId;
    }

    private void setUserId(String userId) {
        this.userId = userId;
    }

    public void setINotificationCallback(IMessageCallback iMessageCallbackCallback) {
        this.iMessageCallbackCallback = iMessageCallbackCallback;
    }

    public boolean unregisterNotificationReceiver() {

        try {
            TmtpBootReceiver tmtpBootReceiver = new TmtpBootReceiver();
            activity.getApplicationContext().unregisterReceiver(tmtpBootReceiver);
            PodPushNotificationReceiver podNotificationReceiver = new PodPushNotificationReceiver();
            activity.getApplicationContext().unregisterReceiver(podNotificationReceiver);
            TmtpPushReceiver tmtpPushReceiver = new TmtpPushReceiver();
            activity.getApplicationContext().unregisterReceiver(tmtpPushReceiver);
            return true;
        } catch (Exception e) {
            Log.e(TAG, "Failed to disable notification");
            return false;
        }


    }


    @Override
    public void onResponse(ResponseModel responseModel) {

        SharedPreferences.setMap(getContext(), true, userId);

        setUserId(userId);

        if (responseListener != null)
            responseListener.onResponse(responseModel);


    }

    @Override
    public void onError(String message) {
        if (responseListener != null) {
            responseListener.onFailure(new Exception(message));
        }
    }

    //
    public static class PushBuilder {
        private AppCompatActivity activity;
        private Context context;
        private String appId;
        private String apiToken;
        private ResponseListener responseListener;

        public PushBuilder() {
        }

        public PushBuilder(AppCompatActivity activity, Context context, String appId, String apiToken) {
            this.activity = activity;
            this.context = context;
            this.appId = appId;
            this.apiToken = apiToken;
        }

        public PushBuilder setActivity(AppCompatActivity activity) {
            this.activity = activity;
            return this;
        }

        public PushBuilder setContext(Context context) {
            this.context = context;
            return this;
        }

        public PushBuilder setAppId(String appId) {
            this.appId = appId;
            return this;
        }

        public PushBuilder setApiToken(String apiToken) {
            this.apiToken = apiToken;
            return this;
        }

        public PushBuilder setResponseListener(ResponseListener responseListener) {
            this.responseListener = responseListener;
            return this;
        }

        public NTFPush build() {
            return new NTFPush(this);
        }

    }

    private void subscribeTMTP() {
        TmtpServiceInitialization tmtpServiceInitialization = new TmtpServiceInitialization(getActivity(), getContext(), getAppId());
        getActivity().getLifecycle().addObserver(tmtpServiceInitialization);

        mapInServer(tmtpServiceInitialization.getUsername());
    }

    private void mapInServer(String userId) {
        ApiContract.ApiPresenter apiPresenter = new ApiPresenterImpl(this);
        boolean isMap = SharedPreferences.isMap(getContext());

        apiPresenter.cancelRequest();
        apiPresenter.setMapOnServer(getApiToken(), userId, getAppId());
    }

    private void registerNotificationReceiver() {


        //add boot receiver
        TmtpBootReceiver tmtpBootReceiver = new TmtpBootReceiver();
        IntentFilter bootReceiverFilter = new IntentFilter();
        bootReceiverFilter.addAction("android.intent.action.BOOT_COMPLETED");
        bootReceiverFilter.addAction("android.intent.action.QUICKBOOT_POWERON");
        activity.getApplicationContext().registerReceiver(tmtpBootReceiver, bootReceiverFilter);


        IntentFilter pushReceiverFilter = new IntentFilter();
        pushReceiverFilter.addAction("com.arissystem.touca.app");
        //add custom notification receiver
        PodPushNotificationReceiver podNotificationReceiver = new PodPushNotificationReceiver();

        podNotificationReceiver.setListener(new OnWorkDone() {
            @Override
            public void onWorkDone(@Nullable Object message) {

                Log.i(TAG, "We got push message: " + message);
                if (iMessageCallbackCallback != null)
                    iMessageCallbackCallback.onPushMessageReceived((String) message);
            }
        });
        try {
            activity.getApplicationContext().registerReceiver(podNotificationReceiver, pushReceiverFilter);
        } catch (Exception e) {
            e.printStackTrace();
            Log.e(TAG, "Failed to enable notification");

        }


    }

}
