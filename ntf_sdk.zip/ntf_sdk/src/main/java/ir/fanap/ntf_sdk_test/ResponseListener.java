package ir.fanap.ntf_sdk_test;

import com.google.gson.JsonObject;

import ir.fanap.ntf_sdk_test.api.ResponseModel;

public interface ResponseListener {
    void onResponse(ResponseModel responseModel);
    void onFailure(Throwable t);
}
