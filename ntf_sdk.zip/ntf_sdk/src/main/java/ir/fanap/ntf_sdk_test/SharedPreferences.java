package ir.fanap.ntf_sdk_test;

import android.content.Context;

/**
 * Created by Sadegh-Pc on 3/7/2018.
 */

public class SharedPreferences {

    public static void setMap(Context context, boolean isMap, String userId) {
        android.content.SharedPreferences settingPreferences = context.getSharedPreferences("map_date", Context.MODE_PRIVATE);
        android.content.SharedPreferences.Editor editor = settingPreferences.edit();


        editor.putBoolean("isMap", isMap);
        editor.putString("userId", userId);

        editor.apply();
    }

    public static boolean isMap(Context context) {
        try {
            android.content.SharedPreferences settingPreferences = context.getSharedPreferences("map_date", Context.MODE_PRIVATE);

            boolean isMap = settingPreferences.getBoolean("isMap", false);

            return isMap;
        } catch (Exception ex) {
            return false;
        }
    }
}
