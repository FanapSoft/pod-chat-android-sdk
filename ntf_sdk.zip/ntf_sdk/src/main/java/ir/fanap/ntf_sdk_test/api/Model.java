package ir.fanap.ntf_sdk_test.api;

public class Model {
    private String userId;
    private String providerAppId;


    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getProviderAppId() {
        return providerAppId;
    }

    public void setProviderAppId(String providerAppId) {
        this.providerAppId = providerAppId;
    }
}
