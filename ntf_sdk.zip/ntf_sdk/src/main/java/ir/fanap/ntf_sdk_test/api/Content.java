package ir.fanap.ntf_sdk_test.api;

public class Content {
    private Model content;

    public Model getContent() {
        return content;
    }

    public void setContent(Model content) {
        this.content = content;
    }
}
