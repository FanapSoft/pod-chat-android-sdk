#include <jni.h>
#include <string>

std::string ACCOUNT_POD_URL = "http://notif-sandbox.pod.ir/";

extern "C" JNIEXPORT jstring JNICALL
Java_ir_fanap_ntf_1sdk_1test_api_ApiUtil_getAccount(JNIEnv *env, jclass clazz) {
    return env->NewStringUTF(ACCOUNT_POD_URL.c_str());
}